﻿using CloudinaryDotNet.Actions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SimpleSocialApp.Data.Enums;
using SimpleSocialApp.Data.Models;
using SimpleSocialApp.Models.ViewModels;
using SimpleSocialApp.Services.Interfaces;
using System.Drawing;
using System.Security.Claims;

namespace SimpleSocialApp.Controllers
{

    public class FriendshipController : Controller
    {
        
    }
}
