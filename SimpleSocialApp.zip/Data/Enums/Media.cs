﻿namespace SimpleSocialApp.Data.Enums
{
    public enum MediaType
    {
        Image,
        Video
    }
}
