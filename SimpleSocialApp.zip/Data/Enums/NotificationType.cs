﻿namespace SimpleSocialApp.Data.Enums
{
    public enum NotificationType
    {
       
    }
}
