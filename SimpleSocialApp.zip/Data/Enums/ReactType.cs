﻿using Microsoft.EntityFrameworkCore.Query.SqlExpressions;

namespace SimpleSocialApp.Data.Enums
{
    public enum ReactType
    {
       Like,
       Love,
       Wow,
       Haha,
       Sad,
       Angry
    }
}
