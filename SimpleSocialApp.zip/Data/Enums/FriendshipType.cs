﻿namespace SimpleSocialApp.Data.Enums
{
    public enum FriendshipType
    {
        Pending,
        Accepted
    }
}
