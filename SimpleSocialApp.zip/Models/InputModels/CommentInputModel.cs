﻿namespace SimpleSocialApp.Models.InputModels
{
    public class CommentInputModel
    {
        //More to be added
        public required string PostId { get; set; }
        public required string Content { get; set; }
    }
}
