﻿namespace SimpleSocialApp.Models.ViewModels
{
    public class EditCommentViewModel
    {
        public required string CommentId { get; set; }
        public required string Content { get; set; }
    }
}
