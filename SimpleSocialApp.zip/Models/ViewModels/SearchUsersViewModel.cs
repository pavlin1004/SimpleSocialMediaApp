﻿namespace SimpleSocialApp.Models.ViewModels
{
    public class SearchUsersViewModel
    {
    }
}
