﻿namespace SimpleSocialApp.Models.ViewModels
{
    public class EditPostViewModel
    {
        public required string PostId { get; set; }
        public required string Text { get; set; }
    }
}
